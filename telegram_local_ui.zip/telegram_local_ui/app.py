import asyncio
import os
import re
from dataclasses import dataclass, asdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from telethon import TelegramClient
from telethon.errors import FloodWaitError, SessionPasswordNeededError

APP_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = APP_DIR / "downloads"
SESSION_PATH = APP_DIR / "song_downloader_session"

SEARCH_TIMEOUT = 25
DOWNLOAD_TIMEOUT = 60
DELAY_BETWEEN_SONGS = 5
MIN_MATCH_SCORE = 0.45

app = FastAPI(title="Telegram Song Downloader UI")


def normalize(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[\(\)\[\]\-_]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def match_score(query: str, candidate: str) -> float:
    return SequenceMatcher(None, normalize(query), normalize(candidate)).ratio()


def best_button(buttons, query):
    best_text, best_score = None, -1.0
    for row in buttons or []:
        for btn in row:
            label = getattr(btn, "text", "") or ""
            score = match_score(query, label)
            if score > best_score:
                best_text, best_score = label, score
    return best_text, best_score


@dataclass
class SongProgress:
    song: str
    status: str = "queued"
    detail: str = ""
    saved_path: Optional[str] = None


class ConnectRequest(BaseModel):
    api_id: int
    api_hash: str
    phone: str
    target_bot: str


class VerifyRequest(BaseModel):
    code: str


class PasswordRequest(BaseModel):
    password: str


class StartRequest(BaseModel):
    songs: str


class DownloaderManager:
    def __init__(self):
        self.client: Optional[TelegramClient] = None
        self.phone: Optional[str] = None
        self.target_bot: Optional[str] = None
        self.authorized = False
        self.running = False
        self.stop_requested = False
        self.items: list[SongProgress] = []
        self.completed = 0
        self.failed = 0
        self.current = ""
        self.last_error = ""
        self._task: Optional[asyncio.Task] = None

    async def reset_client(self):
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass
        self.client = None
        self.authorized = False

    async def connect(self, api_id: int, api_hash: str, phone: str, target_bot: str):
        await self.reset_client()
        self.phone = phone.strip()
        self.target_bot = target_bot.strip()
        self.client = TelegramClient(str(SESSION_PATH), api_id, api_hash)
        await self.client.connect()

        if await self.client.is_user_authorized():
            self.authorized = True
            return {"state": "authorized"}

        await self.client.send_code_request(self.phone)
        return {"state": "need_code"}

    async def verify_code(self, code: str):
        if not self.client or not self.phone:
            raise RuntimeError("Start the sign-in process first.")
        try:
            await self.client.sign_in(phone=self.phone, code=code.strip())
            self.authorized = True
            return {"state": "authorized"}
        except SessionPasswordNeededError:
            return {"state": "need_password"}

    async def verify_password(self, password: str):
        if not self.client:
            raise RuntimeError("Start the sign-in process first.")
        await self.client.sign_in(password=password)
        self.authorized = True
        return {"state": "authorized"}

    async def process_song(self, item: SongProgress):
        if not self.client or not self.target_bot:
            raise RuntimeError("Telegram is not connected.")

        item.status = "searching"
        item.detail = "Sending search to bot..."
        self.current = item.song

        try:
            async with self.client.conversation(self.target_bot, timeout=SEARCH_TIMEOUT) as conv:
                await conv.send_message(item.song)
                response = await conv.get_response()

                if not response.buttons:
                    item.status = "failed"
                    item.detail = "No result buttons returned by the bot."
                    return False

                label, score = best_button(response.buttons, item.song)
                if label is None or score < MIN_MATCH_SCORE:
                    item.status = "failed"
                    item.detail = f"Best match was below threshold ({score:.2f})."
                    return False

                item.status = "downloading"
                item.detail = f"Matched: {label} ({score:.2f})"
                await response.click(text=label)

                audio_msg = await conv.get_response(timeout=DOWNLOAD_TIMEOUT)
                if not audio_msg.media:
                    item.status = "failed"
                    item.detail = "Bot replied, but no media file followed."
                    return False

                DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
                path = await audio_msg.download_media(file=str(DOWNLOAD_DIR) + os.sep)
                item.saved_path = str(path) if path else None
                item.status = "done"
                item.detail = "Downloaded successfully."
                return True

        except asyncio.TimeoutError:
            item.status = "failed"
            item.detail = "Timed out waiting for the bot."
            return False
        except FloodWaitError as e:
            item.status = "waiting"
            item.detail = f"Telegram flood wait: {e.seconds}s"
            await asyncio.sleep(e.seconds)
            if self.stop_requested:
                item.status = "stopped"
                item.detail = "Stopped by user."
                return False
            return await self.process_song(item)
        except Exception as e:
            item.status = "failed"
            item.detail = f"{type(e).__name__}: {e}"
            return False

    async def run(self, songs: list[str]):
        self.running = True
        self.stop_requested = False
        self.items = [SongProgress(song=s) for s in songs]
        self.completed = 0
        self.failed = 0
        self.current = ""
        self.last_error = ""

        try:
            for item in self.items:
                if self.stop_requested:
                    item.status = "stopped"
                    item.detail = "Stopped by user."
                    continue

                ok = await self.process_song(item)
                if ok:
                    self.completed += 1
                else:
                    self.failed += 1

                if not self.stop_requested:
                    await asyncio.sleep(DELAY_BETWEEN_SONGS)
        except Exception as e:
            self.last_error = f"{type(e).__name__}: {e}"
        finally:
            self.current = ""
            self.running = False

    def start(self, songs: list[str]):
        if self.running:
            raise RuntimeError("A download job is already running.")
        self._task = asyncio.create_task(self.run(songs))

    def status(self):
        total = len(self.items)
        finished = self.completed + self.failed
        percent = round((finished / total) * 100, 1) if total else 0
        return {
            "authorized": self.authorized,
            "running": self.running,
            "stop_requested": self.stop_requested,
            "current": self.current,
            "completed": self.completed,
            "failed": self.failed,
            "total": total,
            "percent": percent,
            "last_error": self.last_error,
            "download_dir": str(DOWNLOAD_DIR),
            "items": [asdict(x) for x in self.items],
        }


manager = DownloaderManager()


@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse(INDEX_HTML)


@app.post("/api/connect")
async def api_connect(req: ConnectRequest):
    try:
        return await manager.connect(req.api_id, req.api_hash, req.phone, req.target_bot)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"{type(e).__name__}: {e}")


@app.post("/api/verify")
async def api_verify(req: VerifyRequest):
    try:
        return await manager.verify_code(req.code)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"{type(e).__name__}: {e}")


@app.post("/api/password")
async def api_password(req: PasswordRequest):
    try:
        return await manager.verify_password(req.password)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"{type(e).__name__}: {e}")


@app.post("/api/start")
async def api_start(req: StartRequest):
    if not manager.authorized:
        raise HTTPException(status_code=401, detail="Sign in to Telegram first.")
    songs = [line.strip() for line in req.songs.splitlines() if line.strip()]
    if not songs:
        raise HTTPException(status_code=400, detail="Paste at least one song.")
    try:
        manager.start(songs)
        return {"ok": True, "count": len(songs)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/stop")
async def api_stop():
    manager.stop_requested = True
    return {"ok": True}


@app.get("/api/status")
async def api_status():
    return JSONResponse(manager.status())


@app.post("/api/logout")
async def api_logout():
    if manager.running:
        raise HTTPException(status_code=400, detail="Stop the current download job first.")
    await manager.reset_client()
    return {"ok": True}


INDEX_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Telegram Song Downloader</title>
<style>
:root{color-scheme:dark;--bg:#0b1020;--panel:#121a2f;--text:#eef3ff;--muted:#9ca9c7;--accent:#70a5ff;--ok:#4ed199;--bad:#ff7c91;--line:#2a3756}
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,-apple-system,sans-serif;background:linear-gradient(180deg,#09101f,var(--bg));color:var(--text);min-height:100vh}.wrap{max-width:1100px;margin:auto;padding:28px 18px 60px}h1{margin:0 0 6px;font-size:30px}.sub{color:var(--muted);margin-bottom:22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card{background:#121a2f;border:1px solid var(--line);border-radius:16px;padding:18px}.card h2{font-size:18px;margin:0 0 14px}label{display:block;font-size:13px;color:var(--muted);margin:12px 0 6px}input,textarea{width:100%;border:1px solid var(--line);background:#0c1427;color:var(--text);border-radius:10px;padding:11px 12px;outline:none}textarea{min-height:280px;resize:vertical;font-family:ui-monospace,Menlo,monospace}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}button{border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;background:var(--accent);color:#07101f}button.secondary{background:#243352;color:var(--text)}button.danger{background:var(--bad);color:#240711}.status{margin-top:12px;border:1px solid var(--line);background:#0c1427;border-radius:10px;padding:10px 12px;color:var(--muted);min-height:42px}.ok{color:var(--ok)}.bad{color:var(--bad)}.progress{height:12px;background:#0c1427;border:1px solid var(--line);border-radius:999px;overflow:hidden;margin:12px 0 6px}.bar{height:100%;width:0%;background:linear-gradient(90deg,#70a5ff,#4ed199);transition:width .25s ease}.small{color:var(--muted);font-size:13px}.items{margin-top:14px;max-height:420px;overflow:auto;border-top:1px solid var(--line)}.item{display:grid;grid-template-columns:1fr auto;gap:10px;padding:10px 2px;border-bottom:1px solid var(--line)}.item .name{font-weight:650}.item .detail{color:var(--muted);font-size:12px;margin-top:4px}.badge{font-size:12px;padding:4px 8px;border-radius:999px;background:#23304c;height:max-content}.badge.done{background:#173d32;color:#7bf0bd}.badge.failed{background:#4b1f2a;color:#ff9bac}.badge.downloading,.badge.searching,.badge.waiting{background:#243c63;color:#9ec1ff}.hide{display:none}.full{grid-column:1/-1}@media(max-width:780px){.grid{grid-template-columns:1fr}.full{grid-column:auto}}
</style>
</head>
<body>
<div class="wrap">
<h1>Telegram Song Downloader</h1>
<div class="sub">Local-only browser UI. Paste your list, sign in to Telegram, and watch progress.</div>
<div class="grid">
<section class="card">
<h2>1. Telegram sign-in</h2>
<label>API ID</label><input id="api_id" inputmode="numeric" placeholder="123456">
<label>API Hash</label><input id="api_hash" type="password" placeholder="your_api_hash">
<label>Phone number</label><input id="phone" placeholder="+2547XXXXXXXX">
<label>Target bot</label><input id="target_bot" placeholder="@SomeMusicBot">
<div class="row" style="margin-top:14px"><button onclick="connectTelegram()">Connect / Sign in</button><button class="secondary" onclick="logoutTelegram()">Disconnect</button></div>
<div id="codeBox" class="hide"><label>Telegram login code</label><div class="row"><input id="code" placeholder="12345" style="flex:1"><button onclick="verifyCode()">Verify code</button></div></div>
<div id="passwordBox" class="hide"><label>2FA password</label><div class="row"><input id="password" type="password" placeholder="Telegram 2FA password" style="flex:1"><button onclick="verifyPassword()">Verify password</button></div></div>
<div id="loginStatus" class="status">Not connected.</div>
<div class="small" style="margin-top:10px">Your Telegram session is stored locally beside the app.</div>
</section>
<section class="card">
<h2>2. Song list</h2>
<label>One song per line</label>
<textarea id="songs" placeholder="Artist - Song&#10;Artist - Another Song&#10;..."></textarea>
<div class="row" style="margin-top:12px"><button onclick="startDownloads()">Start downloads</button><button class="danger" onclick="stopDownloads()">Stop</button><span id="songCount" class="small">0 songs</span></div>
<div class="small" style="margin-top:10px">Only download media you have permission or rights to download.</div>
</section>
<section class="card full">
<h2>3. Progress</h2>
<div class="row"><strong id="summary">Idle</strong><span id="current" class="small"></span></div>
<div class="progress"><div id="bar" class="bar"></div></div>
<div id="stats" class="small">0 / 0 complete</div>
<div id="downloadDir" class="small" style="margin-top:6px"></div>
<div id="items" class="items"></div>
</section>
</div>
</div>
<script>
const $=id=>document.getElementById(id);
function setLogin(msg,type=""){$("loginStatus").className="status "+type;$("loginStatus").textContent=msg}
async function post(url,body={}){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});let data={};try{data=await r.json()}catch{}if(!r.ok)throw new Error(data.detail||"Request failed");return data}
async function connectTelegram(){try{setLogin("Connecting...");const data=await post("/api/connect",{api_id:Number($("api_id").value),api_hash:$("api_hash").value,phone:$("phone").value,target_bot:$("target_bot").value});if(data.state==="authorized"){$("codeBox").classList.add("hide");$("passwordBox").classList.add("hide");setLogin("Connected and authorized.","ok")}else{$("codeBox").classList.remove("hide");setLogin("Telegram sent a login code. Enter it below.")}}catch(e){setLogin(e.message,"bad")}}
async function verifyCode(){try{const data=await post("/api/verify",{code:$("code").value});if(data.state==="need_password"){$("passwordBox").classList.remove("hide");setLogin("Code accepted. Enter your Telegram 2FA password.")}else{$("codeBox").classList.add("hide");$("passwordBox").classList.add("hide");setLogin("Connected and authorized.","ok")}}catch(e){setLogin(e.message,"bad")}}
async function verifyPassword(){try{await post("/api/password",{password:$("password").value});$("codeBox").classList.add("hide");$("passwordBox").classList.add("hide");setLogin("Connected and authorized.","ok")}catch(e){setLogin(e.message,"bad")}}
async function logoutTelegram(){try{await post("/api/logout");setLogin("Disconnected.")}catch(e){setLogin(e.message,"bad")}}
async function startDownloads(){try{const data=await post("/api/start",{songs:$("songs").value});$("summary").textContent=`Started ${data.count} songs`}catch(e){alert(e.message)}}
async function stopDownloads(){try{await post("/api/stop")}catch(e){alert(e.message)}}
function esc(s){return(s||"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderStatus(s){$("bar").style.width=`${s.percent||0}%`;$("stats").textContent=`${s.completed+s.failed} / ${s.total} finished • ${s.completed} downloaded • ${s.failed} failed • ${s.percent}%`;$("summary").textContent=s.running?"Downloading...":(s.total?"Finished / stopped":"Idle");$("current").textContent=s.current?`Current: ${s.current}`:"";$("downloadDir").textContent=s.download_dir?`Downloads folder: ${s.download_dir}`:"";$("items").innerHTML=(s.items||[]).map(item=>`<div class="item"><div><div class="name">${esc(item.song)}</div><div class="detail">${esc(item.detail||"")}${item.saved_path?"<br>"+esc(item.saved_path):""}</div></div><span class="badge ${esc(item.status)}">${esc(item.status)}</span></div>`).join("");if(s.authorized)setLogin("Connected and authorized.","ok")}
async function poll(){try{const r=await fetch("/api/status");renderStatus(await r.json())}catch{}}
$("songs").addEventListener("input",()=>{const n=$("songs").value.split(/\r?\n/).filter(x=>x.trim()).length;$("songCount").textContent=`${n} song${n===1?"":"s"}`});
setInterval(poll,1000);poll();
</script>
</body>
</html>'''


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)
