# Telegram Song Downloader - Local UI

This localhost UI wraps the workflow from your PDF: sign in to Telegram, paste a list, process songs one by one through the configured bot, and watch live progress.

Use it only for media you have permission or rights to download.

## Install on macOS

```bash
cd /path/to/telegram_local_ui
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
```

## Run

```bash
python3 app.py
```

Open:

```text
http://127.0.0.1:8000
```

## In the browser

1. Enter your Telegram API ID and API Hash.
2. Enter your phone number with country code.
3. Enter the target Telegram bot username.
4. Click **Connect / Sign in**.
5. Enter the Telegram login code.
6. If 2FA is enabled, enter your Telegram 2FA password.
7. Paste one song per line.
8. Click **Start downloads**.

Downloads are saved in the `downloads/` folder beside the app.

The app keeps the original script's defaults: 25-second search timeout, 60-second media timeout, 5-second delay between songs, and a 0.45 minimum match score.
