#!/bin/bash
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv .venv
fi

source .venv/bin/activate
python3 -m pip install -r requirements.txt

echo "Starting at http://127.0.0.1:8000"
python3 app.py &
APP_PID=$!
sleep 2
open http://127.0.0.1:8000
wait $APP_PID
